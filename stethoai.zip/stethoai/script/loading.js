$(window).load(function(){
  $(".loadingBanner").fadeOut(500);
});
